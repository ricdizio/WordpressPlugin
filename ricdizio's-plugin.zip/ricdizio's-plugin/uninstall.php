<?php

/**
 * @package ricdizio's plugin
 * Uninstall file
 */

 //Security Check
defined('WP_UNISTALL_PLUGIN')  or die();

