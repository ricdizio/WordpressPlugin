<div class="wrap">


<h1>ricdizio's plugin ShortCode</h1>

<h2>How to use the plugin?</h2>
<p>Copy this code: <span><code>[table-plugin]</code></span> in your <b>static page</b> or <b>post</b> using the code editor.</p>


</div>